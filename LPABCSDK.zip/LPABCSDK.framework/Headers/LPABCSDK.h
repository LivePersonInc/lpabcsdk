//
//  LPABCSDK.h
//  LPABCSDK
//
//  Created by LivePerson on 27/06/2018.
//  Copyright © 2018 LivePerson. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LPABCSDK.
FOUNDATION_EXPORT double LPABCSDKVersionNumber;

//! Project version string for LPABCSDK.
FOUNDATION_EXPORT const unsigned char LPABCSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LPABCSDK/PublicHeader.h>


